﻿using System.Web.UI;

namespace WebApplication1_Zakh.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}